import React, {
  createContext,
  useContext,
  useEffect,
  useState,
} from 'react';

export type Language = 'es' | 'ca' | 'en';

interface LanguageContextType {
  language: Language;
  setLanguage: (language: Language) => void;
}

const LanguageContext = createContext<
  LanguageContextType | undefined
>(undefined);

const STORAGE_KEY = 'alpha13_language';

const getInitialLanguage = (): Language => {
  const savedLanguage = localStorage.getItem(STORAGE_KEY);

  if (
    savedLanguage === 'es' ||
    savedLanguage === 'ca' ||
    savedLanguage === 'en'
  ) {
    return savedLanguage;
  }

  return 'es';
};

export const LanguageProvider: React.FC<{
  children: React.ReactNode;
}> = ({ children }) => {
  const [language, setLanguageState] =
    useState<Language>(getInitialLanguage);

  const setLanguage = (newLanguage: Language) => {
    setLanguageState(newLanguage);
    localStorage.setItem(
      STORAGE_KEY,
      newLanguage
    );
  };

  useEffect(() => {
    localStorage.setItem(
      STORAGE_KEY,
      language
    );
  }, [language]);

  return (
    <LanguageContext.Provider
      value={{
        language,
        setLanguage,
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);

  if (!context) {
    throw new Error(
      'useLanguage debe ser usado dentro de un LanguageProvider'
    );
  }

  return context;
};